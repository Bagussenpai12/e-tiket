<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Admin</title>
</head>
<body>
    <div class="sidebar-admin">
        <a href="/lthn-ticket_pesawat/admin/index.php">Dashboard</a>
        <a href="/lthn-ticket_pesawat/admin/pengguna">Data Pengguna</a>
        <a href="/lthn-ticket_pesawat/admin/maskapai">Data Maskapai</a>
        <a href="/lthn-ticket_pesawat/admin/kota">Data Kota</a>
        <a href="/lthn-ticket_pesawat/admin/rute">Data Rute</a>
        <a href="/lthn-ticket_pesawat/admin/jadwal">Data Jadwal Penerbangan</a>
        <a href="/lthn-ticket_pesawat/admin/pemesananTiket">Data Pemesanan Tiket</a>
        <a href="/lthn-ticket_pesawat/logout.php">Logout</a>
    </div>
</body>
</html>