<?php

$conn = mysqli_connect('localhost', 'root', '', 'e-ticketing');

?>