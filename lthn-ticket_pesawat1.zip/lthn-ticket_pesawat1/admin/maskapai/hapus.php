<?php 

require 'functions.php';

$id = $_GET["id"];

if(hapusMaskapai($id) > 0){
    echo "
        <script type='text/javascript'>
            alert('Data maskapai berhasil dihapus');
            window.location = 'index.php';
        </script>
    ";
}else{
    echo "
        <script type='text/javascript'>
            alert(Data maskapai gagal dihapus');
            window.location = 'index.php';
        </script
    ";
}
?>